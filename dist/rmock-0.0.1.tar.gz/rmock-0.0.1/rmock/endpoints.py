#!/usr/bin/env python3
# -*- coding:utf-8 -*-

from .flaskapp import Rmock
from flask import Flask, request, jsonify


def index():

    if request.json:
        Rmock.settings = request.json
        return jsonify(request.json)
    return jsonify({"hello": "world"})
