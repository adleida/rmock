#!/usr/bin/env python3
# -*- coding:utf-8 -*-
# File Name: rmock/app.py
# Author: fanyongtao
# mail: jacketfan826@gmail.com
# Created Time: 2015年05月11日 星期一 16时03分37秒
#########################################################################
import os
import logging
import uuid
import time
import json
from .utils import set_log, compare_dictionaries
from flask import Flask, request, make_response, jsonify


class Rmock(Flask):

    def __init__(self, **kwargs):
        self.conf = {}
        name = kwargs.pop('name', __package__)
        super(Rmock, self).__init__(name, **kwargs)
        self.init()

    def run(self, host=None, port=None, debug=None, **kwargs):
        super(Rmock, self).run(host, port, debug, **kwargs)

    @staticmethod
    def json_dump(data):
        return json.dumps(data, indent=2)

    def init(self):
        os.makedirs('log', exist_ok=True)
        self.add_url_rule('/conf', view_func=self.index, methods=["POST"])
        self.add_url_rule('/dsp/v2', view_func=self.dsp, methods=["GET"])
        self.add_url_rule('/res/v2/<string:did>', view_func=self.res, methods=["POST"])
        self.add_url_rule('/notice/v2/<string:did>', view_func=self.notice, methods=["POST"])
        self.add_url_rule('/log/<string:uuid>', view_func=self.view_log, methods=["GET"])

    def home(self):
        pass

    def index(self):
        if request.json and request.json.get('dsp', {}):
            self.conf = request.json.get('dsp')
            uid = uuid.uuid4()
            set_log(self.logger, uid)
            self.logger.info('uuid = %s ' % uid)
            self.logger.info('conf = %s ' % self.conf)
            return jsonify({
                "conf": True,
                "uuid": uid
            })
        return jsonify({"conf": False})

    def chk(self):
        return jsonify(self.conf)

    def dsp(self):
        tmp = self.conf.get('s', [])
        res = [{
            'name': it['name'],
            'burl': it['burl'],
            'id': it['id']
        } for it in tmp]
        td = self.json_dump(res)
        self.logger.info('provide dsp info start'.center(40, '='))
        self.logger.info('dsp_info >>> %s' % td)
        self.logger.info('provide dsp info end'.center(40, '='))
        return td

    def view_log(self, uuid):
        try:
            with open('log/%s' % uuid) as f:
                response = make_response(f.read())
                response.headers['Content-Type'] = 'text/plan'
                return response
        except Exception as ex:
            return str(ex)


    def res(self, did):
        self.logger.info('====%s Get bid request start====' % did)
        self.logger.info('bid_request >>> %s' % self.json_dump(request.json))
        self.logger.info('====%s Get bid request end====' % did)
        tmp = self.conf.get('s', [])
        tt = [(it['id'], it.get('res_file', {}), it['is_res'], it['name'], it.get('notice_file', {})) for it in tmp]
        for l in tt:
            if l[0] == did:
                if l[2]:
                    res_data = l[1]
                    rid = res_data.get('id', '')
                    if not rid:
                        res_data['id'] = request.json['id']
                    self.logger.info('Response bid request start'.center(40, '='))
                    self.logger.info('bid_response >>> %s' % self.json_dump(res_data))
                    self.logger.info('Response bid request end'.center(40, '='))
                    return jsonify(res_data)
                else:
                    time.sleep(2)
        return jsonify({"j": "b"})

    def notice(self, did):
        tmp = self.conf.get('s', [])
        tt = [(it['id'], it.get('res_file', {}), it['is_res'], it['name'], it.get('notice_file', {})) for it in tmp]
        self.logger.info('===%s Get bid notice start===' % did)
        self.logger.info('bid_notice >>> %s' % self.json_dump(request.json))
        self.logger.info('===%s Get bid notice end===' % did)
        for i in tt:
            if did == i[0]:
                try:
                    data_json = i[4]
                    request.json.pop('id')
                    compare_dictionaries(request.json, data_json)
                    self.notice_win = True
                except Exception as ex:
                    self.notice_win = False
                    print(ex)
            continue
        res_notice = {
            "message": "{} get notice".format(did),
            "time": time.time()
        }
        self.logger.info('Response bid notice start'.center(40, '='))
        self.logger.info('response_notice >>> %s' % self.json_dump(res_notice))
        self.logger.info('Response bid notice end \n\n\n')
        return jsonify(res_notice)
