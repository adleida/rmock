#!/usr/bin/env python3
# -*- coding:utf-8 -*-
# File Name: rmock/__init__.py
# Author: fanyongtao
# mail: jacketfan826@gmail.com
# Created Time: 2015年05月11日 星期一 15时31分10秒
#########################################################################

__version__ = '0.0.4'
